package com.example.demo.entity;

import javax.persistence.*;

@Entity
@Table(name="customers")
public class Customer {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int id;
private String firstname;
private String lastName;
private String gender;
private String address;
private String email;
private String password;

public Customer() {
	super();
}

public Customer(int id, String firstname, String lastName, String gender, String address, String email,
		String password) {
	super();
	this.id = id;
	this.firstname = firstname;
	this.lastName = lastName;
	this.gender = gender;
	this.address = address;
	this.email = email;
	this.password = password;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getFirstname() {
	return firstname;
}

public void setFirstname(String firstname) {
	this.firstname = firstname;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}


public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

@Override
public String toString() {
	return "Customer [id=" + id + ", firstname=" + firstname + ", lastName=" + lastName + ", gender=" + gender
			+  ", address=" + address + ", email=" + email + ", password=" + password + "]";
}

}


